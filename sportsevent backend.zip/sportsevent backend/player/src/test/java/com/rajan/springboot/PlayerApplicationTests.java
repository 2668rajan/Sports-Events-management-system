package com.rajan.springboot;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sportseventmanagement.PlayerApplication;
import com.sportseventmanagement.dao.PlayerDao;
import com.sportseventmanagement.entities.Players;
import com.sportseventmanagement.service.PlayerService;

@SpringBootTest(classes = PlayerApplication.class)
class PlayerApplicationTests {
	
	@Autowired
	private PlayerDao repo;
	
	@Autowired
	PlayerService service;
	
	

	@Test
	void contextLoads() {
	}
	
	@BeforeEach
	void setUp() {
		Players player = new Players(1001l, "Rajan", 23, "8779298256", "2668rajan@gmail.com", "male", "Cricket");
		repo.save(player);
	}
	
	@Test
	void getPlayers() {
		List<Players> actual = repo.findAll();
		assertThat(actual).asList();
	}
	
	@Test
	void getPlayer() {
		Optional<Players> actual = repo.findById(1001l);
		assertThat(actual).isNotEmpty();
	}
	
	@Test
	void addPlayer() {
		Players player = new Players(1011l, "Rajan", 23, "8779298256", "2668rajan@gmail.com", "male", "Cricket");
		service.addPlayer(player);
		Players player2 = new Players(1011l, "Rajan", 23, "8779298256", "2668rajan@gmail.com", "male", "Cricket");
		service.addPlayer(player2);
	}
	
	
	@Test
	void deletePlayer() {
	repo.deleteById(1001l);
	}
	
	@Test
	void playerExistsByName() {
		boolean playerExists = service.playerExists("Rajan");
		assertThat(playerExists).isTrue();
	}
	
	@Test
	void playrExistsById() {
		boolean playerExists = service.playerExists(1001l);
		assertThat(playerExists).isTrue();
	}

}
